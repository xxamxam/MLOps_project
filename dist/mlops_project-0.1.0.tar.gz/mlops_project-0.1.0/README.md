# MLOps_project
project for mlops course
