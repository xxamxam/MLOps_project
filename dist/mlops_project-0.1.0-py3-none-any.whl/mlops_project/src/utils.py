import datetime

class CacheItem(object):
    def __init__(self, key, item):
        pass


